import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-tbl',
  templateUrl: './book-tbl.component.html',
  styleUrls: ['./book-tbl.component.css']
})
export class BookTblComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
