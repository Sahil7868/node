export class Cityclass {
    public constructor(public pk_city_id:number,public city_name:string)
    {

    }
}
