export class Eventclass {
    public constructor(public pk_event_id:number,public event_name:string,
    public event_logo:string,public event_slogan:string,
    public event_des:string,public fk_venue_id:number,public event_date:string,
    public event_time:string,public event_price:number,public fk_cat_id:number,
    public fk_email_id:string,public fk_offer_id:number,public event_cnt:number,
    public flag:number)
    {

    }
}

{
    
    