export class Ansclass {
    public constructor(public pk_que_id:number,public fk_email_id:string,
    public fk_event_id:number,public que_desc:string,public que_date:string,
    public pk_ans_id:number,public fk_que_id:number,public ans_desc:string,public ans_date:string)
    {

    }
}

